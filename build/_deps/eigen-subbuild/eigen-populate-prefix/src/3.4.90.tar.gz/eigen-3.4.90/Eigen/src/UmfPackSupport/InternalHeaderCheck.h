#ifndef EIGEN_UMFPACKSUPPORT_MODULE_H
#error "Please include Eigen/UmfPackSupport instead of including headers inside the src directory directly."
#endif
